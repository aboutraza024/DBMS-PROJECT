from flask import Flask,render_template,request,url_for,session,redirect,send_file
from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,validators,IntegerField
import random
from flask_mail import Mail,Message
import password as p
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from io import BytesIO
verification_code=str(random.randint(100000,999999))
app=Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"]="mysql://root:@localhost/semester project management system"
app.config["SECRET_KEY"]="SECRETKEY"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db=SQLAlchemy(app)
class projects(db.Model):
    p_number=db.Column(db.Integer,primary_key=True,autoincrement=True)
    i_comments=db.Column(db.String(255))
    e_comments = db.Column(db.String(255))
    aceptreject = db.Column(db.String(55))
    assignscore=db.Column(db.Integer)
    title = db.Column(db.String(255))
    position = db.Column(db.String(255))
    instructormail = db.Column(db.String(255))


    def __repr__(self):
        return f"< instructorfile {self.p_number} {self.i_comments} {self.e_comments}  {self.aceptreject} {self.assignscore} {self.title} {self.position} {self.instructormail}>"


class instructorfile(db.Model):
    fileid=db.Column(db.Integer,primary_key=True,autoincrement=True)
    filename=db.Column(db.String)
    data = db.Column(db.LargeBinary)
    SerialNO=db.Column(db.String(255))

    def __repr__(self):
        return f"< instructorfile {self.fileid} {self.filename} {self.SerialNO} >"


class coordinatorfile(db.Model):
    fileid=db.Column(db.Integer,primary_key=True,autoincrement=True)
    filename=db.Column(db.String)
    data = db.Column(db.LargeBinary)
    cmail=db.Column(db.String(255))

    def __repr__(self):
        return f"< coordinatorfile {self.fileid} {self.filename} {self.cmail} >"


class teamcoordinator(db.Model):
    name=db.Column(db.String(255),nullable=False)
    email=db.Column(db.String(255),nullable=False,unique=True)
    enrollment_number=db.Column(db.String(255),primary_key=True)
    department=db.Column(db.String(255),nullable=False)
    semester=db.Column(db.Integer,nullable=False)
    section = db.Column(db.String(25), nullable=False)
    password=db.Column(db.String(255),nullable=False)
    Students = db.relationship('students', backref='teamcoordinator', lazy=True)
    instructoremail=db.Column(db.String(255))

    def __repr__(self):
        return f'<TeamCoordinator {self.name} {self.email} {self.enrollment_number} {self.department} {self.semester} {self.section} {self.password} {self.instructoremail}>'
class faculty(db.Model):
    name=db.Column(db.String(255),nullable=False)
    email=db.Column(db.String(255),nullable=False,unique=True)
    faculty_number=db.Column(db.Integer,primary_key=True,autoincrement=True)
    department=db.Column(db.String(255),nullable=False)
    password=db.Column(db.String(255),nullable=False)
    role=db.Column(db.String(255))
    def __repr__(self):
        return f'<faculty {self.name} {self.email} {self.faculty_number} {self.department} {self.password} {self.role} >'
class instructor(db.Model):
    instructor_id=db.Column(db.String(25),primary_key=True,)
    def __repr__(self):
        return f"< instructor {self.instructor_id} >"

class evaluator(db.Model):
    instructor_id=db.Column(db.String(25),primary_key=True)
    def __repr__(self):
        return f"< instructor {self.instructor_id} >"

class administrator(db.Model):
    instructor_id=db.Column(db.String(25),primary_key=True)
    def __repr__(self):
        return f"< instructor {self.instructor_id} >"

class projectideas(db.Model):
    idea_no=db.Column(db.Integer,primary_key=True,autoincrement=True)
    title=db.Column(db.String(512))
    fmail=db.Column(db.String(512))
    def __repr__(self):
        return f"< projectideas {self.idea_no} {self.title} >"



class students(db.Model):
    enrollment_number=db.Column(db.String(255),primary_key=True)
    name=db.Column(db.String(255),nullable=False)
    semester=db.Column(db.Integer,nullable=False)
    section=db.Column(db.String(40),nullable=False)
    tenrollment_number = db.Column(db.String(255), db.ForeignKey('teamcoordinator.email'), nullable=False)
    # by mistake i will use  tenrollment_number except email
    def __repr__(self):
        return f'<student {self.enrollment_number} {self.name} {self.semester} {self.section} {self.tenrollment_number}>'

class tasks(db.Model):
    tasknum=db.Column(db.Integer,primary_key=True)
    tasktitle=db.Column(db.String(255))
    deadline=db.Column(db.String(50))
    taskdes=db.Column(db.String(1024))
    femail=db.Column(db.String(255))

    def __repr__(self):
        return f'<tasks {self.tasknum} {self.tasktitle} {self.deadline} {self.taskdes}>'

class projectideasbycoorndinator(db.Model):
    p_id=db.Column(db.Integer,primary_key=True,autoincrement=True)
    p_title=db.Column(db.String(512))
    coordinatorname=db.Column(db.String(55))
    inst_email=db.Column(db.String(255))

def __repr__(self):
    return f"projectideasbycoorndinator {self.p_id} {self.p_title}  {self.coordinatorname} {self.inst_email}"

app.config["SECRET_KEY"]="SECRETKEY"
app.config["MAIL_SERVER"]="smtp.gmail.com"
app.config["MAIL_PORT"]=465
app.config["MAIL_USE_SSL"]=True
app.config["MAIL_USERNAME"]="itsaaliraza@gmail.com"
app.config["MAIL_PASSWORD"]=p.password1
mail=Mail(app)

def dbinsertion(entry):
    try:
        db.session.add(entry)
        db.session.commit()
        return None
    except Exception as e:
        db.session.rollback()
        return e
def dbinsertion1(entry):
    try:
        db.session.add(entry)
        print(entry)
        db.session.commit()
        return None
    except Exception as e:
        db.session.rollback()
        return e
def sendvfcode(email):
        try:
            msg = Message("VERIFICATION CODE",
                          sender="SEMESTERPROJECTMANAGMENTSYSTEM@gmail.com",
                          recipients=[email],
                          body="VERIFICATION CODE IS " + verification_code
                          )
            mail.send(msg)      #bad ma comment out karna ha kyn ka is tarah bar bar email aty ha
        except Exception as e:
            print("EMAIL NOT SEND")
            print(e)
@app.route("/")
def hello():
    return render_template('Dashboard.html')


verificationcode=""
@app.route("/verification",methods=['GET','POST'])
def verification2():
    verificationcode = ""
    class verification1(FlaskForm):
        verification = StringField('verification',
                                   [validators.DataRequired("Enter Six Digits Code"), validators.Length(min=6, max=6)])
    form5 = verification1()
    if request.method=="POST" and form5.validate():
        pass
    if request.method=="POST":
        verificationcode=request.form.get('verification')
        print(type(verificationcode))
        print(type(verification_code))
        print(verificationcode,verification_code)
    return render_template("verification.html",form5=form5,verification_code=verification_code,verificationcode=verificationcode)

@app.route("/loginsignup",methods=['GET','POST'])
def han():
    entry=""
    error=""
    error2=""
    class TEAMFORMLOGIN(FlaskForm):
        email=StringField('Email',[validators.DataRequired("Please Enter Email"),validators.Email("Please enter a valid email")])
        password=PasswordField('Password',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 charachters")])
    class TEAMFORMSIGNUP(FlaskForm):
        name=StringField('Name',[validators.DataRequired("Please enter name"),validators.Length(min=5,max=20,message="Enter name between 5-20 characters")])
        email1 = StringField('Email', [validators.DataRequired("Please Enter Email"),
                                      validators.Email("Please enter a valid email")])
        enrollment_no = StringField('enrollment_no', [validators.DataRequired("Please Enter Enrollment Number"),
                                                      validators.Length(min=13, max=13,
                                                                        message="Enter 12 Number Enrollment ID")])
        department = StringField('Department', [validators.DataRequired("Please enter department name")])
        semester = IntegerField('Semester', [validators.DataRequired("Please enter semester"),validators.NumberRange(min=0,max=8,message="Please enter number between 0 to 8")])
        section = StringField('Section', [validators.DataRequired("Please enter section")])
        password1 = PasswordField('Password',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 charachters")])
        cpassword = PasswordField('CPassword',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 charachters")])
    form1=TEAMFORMLOGIN()
    form2 = TEAMFORMSIGNUP()
    team=""
    if request.method=="POST" and form1.validate():
        #check here email details
        try:
            email = request.form.get('email')
            password = request.form.get('password')
            team = teamcoordinator.query.filter_by(email=email).first()
            if password == team.password:
                session['user_email']=email
                return redirect(url_for('teamcoordinater'))
                return render_template("TEAM.HTML")
            else:
                loginerror="invalid input"
        except Exception as e:
            loginerror="Invalid input"
        return render_template("loginsignup.html",loginerror=loginerror,form2=form2,form1=form1,team=team)     # ider page daalna ha jahan login ka bad jay ga
    if request.method=="POST" and form2.validate():
        return render_template("loginsignup.html")
    if request.method=="POST":
        name=request.form.get('name')
        email=request.form.get('email1')
        enrollment_number=request.form.get('enrollment_no')
        department=request.form.get('department')
        semester=request.form.get('semester')
        section=request.form.get('section')
        password=request.form.get('password1')
        cpassword=request.form.get('cpassword')
        if name!="" and email!="" and enrollment_number!="" and department!="" and semester!=0 and section!="" and password!="" and password==cpassword:
            entry=teamcoordinator(name=name,email=email,enrollment_number=enrollment_number,department=department,semester=semester,section=section,password=password,instructoremail="no")
            print(entry)
        #db.session.add(entry)
            error=dbinsertion(entry)
        #db.session.commit()
        error2="Primary Key Constraint violation Due To Duplicate Enrollment No"
    return render_template('loginsignup.html',form1=form1,form2=form2,error=error,error2=error2,team=team)


@app.route("/loginsignues",methods=['GET','POST'])
def logvsign():
    error1=""
    error3=""
    class TEAMFORMLOGIN(FlaskForm):
        femail=StringField('Email',[validators.DataRequired("Please Enter Email"),validators.Email("Please enter a valid email")])
        fpassword=PasswordField('Password',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 charachters")])
    class TEAMFORMSIGNUP(FlaskForm):
        fname=StringField('Name',[validators.DataRequired("Please enter name"),validators.Length(min=5,max=20,message="Enter name between 5-20 characters")])
        femail1 = StringField('Email', [validators.DataRequired("Please Enter Email"),
                                      validators.Email("Please enter a valid email")])
        fenrollment_no = StringField('enrollment_no', [validators.DataRequired("Please Enter Enrollment Number"),
                                                      validators.Length(min=13, max=13,
                                                                        message="Enter 12 Number Enrollment ID")])
        fdepartment = StringField('Department', [validators.DataRequired("Please enter department name")])
        fpassword1 = PasswordField('Password',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 charachters")])
        fcpassword = PasswordField('cPassword',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 charachters")])
    form3=TEAMFORMLOGIN()
    form4 = TEAMFORMSIGNUP()
    team=""
    loginerror=""
    if request.method=="POST" and form3.validate():
        try:
            email = request.form.get('femail')
            password = request.form.get('fpassword')
            role1 = request.form.get("dropdown")
            team = faculty.query.filter_by(email=email).first()
            print(email,password,role1)
            print(team.password,team.email,team.role)
            if password == team.password and team.email==email and role1==team.role:
                if role1=="Instructor":
                    session['user_email1'] = email
                    return redirect(url_for('instructorfun'))
                    return render_template("INSTRUCTOR.HTML")
                if role1=="Evaluator":
                    session['user_email2'] = email
                    return redirect(url_for('evaluatorm'))
                    return render_template("EVALUATOR.HTML")
                if role1=="Administrator":
                    session['user_email3'] = email
                    return redirect(url_for('admini'))
                    return render_template("ADMIN.HTML")
            else:
                loginerror="Invalid input"
        except Exception as e1:
            loginerror="Invalid input"
            print(e1)
        return render_template("loginsignues.html",loginerror=loginerror,form3=form3,form4=form4,team=team)
    if request.method=="POST" and form4.validate():
        role=request.form.get("dropdown")
        print(role)
    if request.method=="POST":
        name=request.form.get('fname')
        email=request.form.get('femail1')
        enrollment_number=request.form.get('fenrollment_no')
        department=request.form.get('fdepartment')
        password=request.form.get('fpassword1')
        cpassword=request.form.get("fcpassword")
        role = request.form.get("dropdown")
        if name!="" and email!="" and enrollment_number!="" and department!="" and password!="" and role!="" and password==cpassword:
            entry=faculty(name=name,email=email,department=department,password=password,role=role)
            error1=dbinsertion1(entry)
            print(enrollment_number,password,department,entry)
        if enrollment_number!="":
            if role=="Instructor":
                entry=instructor(instructor_id=enrollment_number)
                error1=dbinsertion1(entry)
            if role=="Evaluator":
                entry=evaluator(instructor_id=enrollment_number)
                error1 = dbinsertion1(entry)
            if role=="Administrator":
                entry=administrator(instructor_id=enrollment_number)
                error1 = dbinsertion1(entry)
        print(error1)
        error3="Primary Key Constraint violation Due To Duplicate"
    return render_template("loginsignues.html",form3=form3,form4=form4,error1=error1,error3=error3,team=team)
@app.route("/forgetpassword",methods=['GET','POST'])
def forget():
    loginerror=""
    team=""
    class forgetpassword(FlaskForm):
        email=StringField("Email",[validators.DataRequired("Enter data into the field"),validators.Email("Please enter valid email")])
        password = PasswordField('cPassword',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 characters")])
        cpassword = PasswordField('cPassword',[validators.DataRequired("Enter Password"),validators.Length(min=8,max=30,message="Enter Password between 8 To 30 characters")])
    form3=forgetpassword()
    if request.method=="POST" and form3.validate():
        email=request.form.get("email")
        password=request.form.get("password")
        cpassword=request.form.get("cpassword")
        role = request.form.get("dropdown")
        print(role)
        print(email,password,cpassword)
        sendvfcode(email)
        try:

            if role == "Team Coordinator":
                team = teamcoordinator.query.filter_by(email=email).first()
                if team.email == None:
                    loginerror = "INVALID EMAIL"
                team.password = password
                db.session.commit()
            else:
                team = faculty.query.filter_by(email=email).first()
                team.password = password
                db.session.commit()

        except Exception as e:
            print(e)

    return render_template("forgetpassword.html",form3=form3,loginerror=loginerror,team=team)


@app.route("/Teamcoordinator",methods=['GET','POST'])
def teamcoordinater():
    error=""
    p_title=""
    updateerror=""
    approveerror=""
    instructoremail2=""
    approve=""
    theading=[]
    user_email=session.get('user_email')
    if not user_email:
        return redirect(url_for('han'))
    if request.method=="POST":
        name=request.form.get("name")
        enrollment=request.form.get("enrollment")
        semester=request.form.get("semester")
        section=request.form.get("section")
        p_title=request.form.get("ProjectTitle")
        instructoremail2=request.form.get("Instructor")
        instructoremail1 = request.form.get("Instructor1")

        coordinatorname=user_email
        if instructoremail1!="":
            team=teamcoordinator.query.filter_by(email=coordinatorname).first()
            team.instructoremail=instructoremail1
            db.session.commit()
        if name!="" and enrollment!="" and section!="" and semester!="":
            entry=students(enrollment_number=enrollment,name=name,semester=semester,section=section,tenrollment_number=user_email)
            error=dbinsertion(entry)
    student=students.query.filter_by(tenrollment_number=user_email).all()
    if request.method=="POST":
        name1=request.form.get("name2")
        enrollment1=request.form.get("enrollment2")
        semester1=request.form.get("semester2")
        section1=request.form.get("section2")
        p_title1=request.form.get("ProjectTitle2")
        instructoremail21=request.form.get("Instructor2")
        option=request.form.get("dropdown")
        #print(name1,enrollment1,semester1,section1,p_title1,instructoremail21,option)
        try:
            if option == "DELETE":
                student1 = students.query.filter_by(name=name1).first()
                db.session.delete(student1)
                db.session.commit()
            else:
                updateerror = "Enter Correct Enrollment Number"
            if option == "EDIT":
                student1 = students.query.filter_by(enrollment_number=enrollment1).first()
                print(student1)
                student1.name=name1
                student1.enrollment_number = enrollment1
                student1.semester=semester1
                student1.section=section1
                db.session.commit()
            else:
                updateerror = "Enter Correct Enrollment Number"
        except Exception as e:
            updateerror = "Enter Correct Enrollment Number"
    if p_title!="" and instructoremail2!="":
        SelectedorRejected = ""
        entry=projectideasbycoorndinator(p_title=p_title,coordinatorname=user_email,inst_email=instructoremail2)
        error=dbinsertion(entry)
    theading = ["Name", "Enrollment Number", "Section", "Semester"]
    pidea=projectideas.query.all()
    try:
        approve = projects.query.filter_by(title=p_title).first()
        print("hello",approve.aceptreject)
    except Exception as e:
        approveerror = "Instructor Does not Perform any Action"
        print(e)
    return render_template("TEAM.HTML",error=error,user_email=user_email,student=student,theading=theading,pidea=pidea,approveerror=approveerror,approve=approve,updateerror=updateerror)

@app.route("/instructor",methods=["POST","GET"])
def instructorfun():
    files=""
    SerialNO = ""
    tasktitle=""
    user_email1 = session.get('user_email1')
    if not user_email1:
        return redirect(url_for('logvsign'))
    try:
        if request.method == "POST":
            tasktitle = request.form.get("semester")
            taskdes = request.form.get("pdes")
            date = request.form.get("datepicker")
            time = request.form.get("timepicker")
            deadline = f"{date},{time}"
            print(tasktitle, taskdes, deadline,taskdes)

            entry1 = tasks(tasktitle=tasktitle,deadline=deadline, taskdes=taskdes,femail=user_email1)
            if tasktitle != "" and taskdes != "" and deadline != "" and user_email1 != "":
                dbinsertion(entry1)
    except Exception as e:
        print(e)

    # get files from databse
    try:
        # upload file
        if 'file' in request.files:
            file = request.files['file']
            if file.filename != '':
                filename = secure_filename(file.filename)
                file_data = file.read()
                new_file = instructorfile(filename=filename, data=file_data,SerialNO=tasktitle)
                db.session.add(new_file)
                db.session.commit()
    except Exception as e:
        fileerror="UPLOAD .TXT or .DOCS FILE ONLY"
        print(e)
    try:
        files=instructorfile.query.all()
    except Exception as e:
        db.session.rollback()
        print(e)
    print(files)
    #print(files.fileid,files.filename,files.data)


    if request.method=="POST":
        title=request.form.get('semesterp')
        print(title)
        entry=projectideas(title=title,fmail=user_email1)
        if title!="" and user_email1!="":
            dbinsertion(entry)
        # add project ideas
    pidea=projectideas.query.filter_by(fmail=user_email1)

    try:
        if request.method == "POST":
            title = request.form.get("ptitle")
            idea_no = request.form.get("psrno")
            operation = request.form.get("dropdown")
            print(title,idea_no,operation)
        if operation == "DELETE":
            pidea1 = projectideas.query.filter_by(idea_no=idea_no).first()
            db.session.delete(pidea1)
            db.session.commit()
        else:
            error = "VALUES NOT EXIST IN DATABASE"
        if operation == "EDIT":
            pidea1 = projectideas.query.filter_by(idea_no=idea_no).first()
            pidea1.title = title
            db.session.commit()
        else:
            error = "Select Dropdown Option"
            print(idea_no, title, operation)
    except Exception as e:
        error = "Insert InPUT"
        fileerror = ""

    session['task_title'] = tasktitle
    projectsbycoordinator=projectideasbycoorndinator.query.all()
    proj=projects.query.all()

    return render_template("INSTRUCTOR.HTML",user_email1=user_email1,pidea=pidea,error=error,proj=proj,projectsbycoordinator=projectsbycoordinator)



@app.route("/uploadfile",methods=["POST","GET"])

def uploadfile():
    upload=""
    new_file=""
    fileerror=""
    uploadfile=""
    error=""
    user_email = session.get('user_email')
    cmail=session.get("user_email")
    print(cmail)
    try:
        team = teamcoordinator.query.filter_by(email=user_email).first()
        team1 = team.instructoremail
        uploadfile = tasks.query.filter_by(femail=team1).all()

    except Exception as e:
        print(e)
        error="Team coordinator has not work with any instructor"

    tasktitle=session.get('task_title')
    files=instructorfile.query.all()
    print()
    #files=instructorfile.query.filter_by(SerialNO=tasktitle)
    project=projects.query.all()
    print(tasktitle)
    try:
        # upload file
        file=""
        new_file=""
        if 'file' in request.files:
            file = request.files['file']
            if file.filename != '':
                filename = secure_filename(file.filename)
                file_data = file.read()
                new_file = coordinatorfile(filename=filename, data=file_data,cmail=cmail)
                db.session.add(new_file)
                db.session.commit()
                upload="file uploaded successfully"
    except Exception as e:
        upload = "error"
        fileerror="File ALREADY UPLOADED"
        print(e)




    return render_template("uploadfile.html",error=error,uploadfile=uploadfile,files=files,tasktitle=tasktitle,SerialNO=tasktitle,new_file=new_file,upload=upload,project=project,fileerror=fileerror,user_email=user_email)



@app.route("/pproject",methods=["POST","GET"])
def previousproject():
    user_email = session.get('user_email')
    previousprojects = projects.query.all()
    return render_template("pproject.html",user_email=user_email,previousprojects=previousprojects)


@app.route("/approveidea",methods=["POST","GET"])
def approveideas():

        instructor_email = session.get("user_email1")
        files = projectideasbycoorndinator.query.all()
        if request.method == "POST":
            title = request.form.get("protitle")
            option = request.form.get("dropdown1")
            print("hello", option, title)
            user_email = session.get('user_email')
            print(user_email, title, option)
            try:
                if option == "APPROVED":
                    if title != "" and option != "":
                        entry = projects(i_comments="no", e_comments="no", aceptreject=option, assignscore=0,
                                         title=title, position="no", instructormail=instructor_email)
                        dbinsertion1(entry)
                else:
                    if title != "" and option != "":
                        entry = projects(i_comments="no", e_comments="no", Semester="", aceptreject=option,
                                         assignscore=0,
                                         title=title, instructormail=instructor_email)
                        dbinsertion1(entry)
            except Exception as e:
                print(e, "error")



        return render_template("approveidea.html",files=files,instructor_email=instructor_email)

@app.route("/viewproject",methods=["POST","GET"])
def viewprojects():
    upload = ""
    new_file = ""
    cmail = session.get("user_email")
    print(cmail)
    instructor_email=session.get("user_email1")
    uploadfile = tasks.query.filter_by(femail=instructor_email).all()
    print(uploadfile)

    tasktitle = session.get('task_title')
    files=coordinatorfile.query.all()
    #files = coordinatorfile.query.filter_by(cmail=tasktitle)

    return render_template("viewproject.html",files=files,uploadfile=uploadfile,instructor_email=instructor_email,cmail=cmail)




@app.route("/previousinstructor",methods=["POST","GET"])
def previousfaculty():
    user_email1 = session.get('user_email1')
    previousprojects=projects.query.all()
    return render_template("previousinstructor.html",user_email1=user_email1,previousprojects=previousprojects)

@app.route("/evaluatebyinstructor",methods=["POST","GET"])
def marks():
    error=""
    user_email1 = session.get('user_email1')
    print(user_email1,"???")
    try:
        if request.method == "POST":
            task_t = request.form.get("tasktit")
            t_marks = request.form.get("taskm")
            cemail = request.form.get("coordinatormail")
            t_comments = request.form.get("comments")

            # addicomments = projects.query.all()
            addicomments = projects.query.filter_by(title=task_t).first()
            addicomments.i_comments = t_comments
            addicomments.assignscore = t_marks
            db.session.commit()
    except Exception as e:
        print(e)
        error="ADD COMMENTS PLEASE"

    return render_template("evaluatebyinstructor.html",user_email1=user_email1,error=error)


@app.route("/evaluator",methods=["POST","GET"])
def evaluatorm():
    evaluator=session.get('user_email2')
    print(evaluator,"???")
    approvedproject = projects.query.all()
    cprojects = projectideasbycoorndinator.query.all()
    iprojects = projectideas.query.all()

    return render_template("EVALUATOR.html",evaluator=evaluator,approvedproject=approvedproject,iprojects=iprojects,cprojects=cprojects)



#@app.route("/evaluatorview",methods=["POST","GET"])
#def evaluatorview():
#    return render_template("evaluatorview.html")
@app.route("/evaluatesbyevaluater",methods=["POST","GET"])
def evaluator():
    evaluator = session.get('user_email2')
    if request.method=="POST":
        task_t=request.form.get("etasktit")
        eposition=request.form.get("etaskm")
        t_comments=request.form.get("ecomments")
        addicomments=projects.query.filter_by(title=task_t).first()
        addicomments.e_comments=t_comments
        addicomments.position=eposition

        db.session.commit()
    return render_template("evaluatesbyevaluater.html",evaluator=evaluator)


@app.route("/evaluatorprevoius",methods=["POST","GET"])
def evaluatorpp():
    evaluator=session.get('user_email2')
    previousprojects = projects.query.all()
    return render_template("evaluatorprevoius.html",evaluator=evaluator,previousprojects=previousprojects)


@app.route("/ADMIN",methods=["POST","GET"])
def admini():
    adminmail=session.get('user_email3')
    print(adminmail)
    approvedproject=projects.query.all()
    cprojects=projectideasbycoorndinator.query.all()
    iprojects=projectideas.query.all()
    teamc=teamcoordinator.query.all()
    instructord = faculty.query.filter_by(role="INSTRUCTOR")
    evaluatord = faculty.query.filter_by(role="EVALUATOR")
    admind = faculty.query.filter_by(role="ADMINISTRATOR")
    return render_template("ADMIN.html",adminmail=adminmail,approvedproject=approvedproject,cprojects=cprojects,iprojects=iprojects,teamc=teamc,instructord=instructord,evaluatord=evaluatord,admind=admind)


@app.route("/download/<int:fileid>",methods=["POST","GET"])
def download(fileid):
    file=instructorfile.query.get_or_404(fileid)
    return send_file(BytesIO(file.data),download_name=file.filename, as_attachment=True)

@app.route("/download/coordinator/<int:fileid>", methods=["POST", "GET"])
def download_coordinator(fileid):
    file = coordinatorfile.query.get_or_404(fileid)
    return send_file(BytesIO(file.data), download_name=file.filename, as_attachment=True)

# saab pages pa ja ka links daal kaka

app.run(debug=True)